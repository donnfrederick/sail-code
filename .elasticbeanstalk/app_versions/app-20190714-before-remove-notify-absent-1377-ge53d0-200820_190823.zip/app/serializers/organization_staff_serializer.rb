class OrganizationStaffSerializer < ActiveModel::Serializer
  attributes :id, :auth_token
end

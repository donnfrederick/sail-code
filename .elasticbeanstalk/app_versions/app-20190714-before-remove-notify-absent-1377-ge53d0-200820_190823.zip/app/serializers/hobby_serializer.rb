class HobbySerializer < ActiveModel::Serializer
  attributes :id, :name
end

class AccusationReasonSerializer < ActiveModel::Serializer
  attributes :id, :name
end

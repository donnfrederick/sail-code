class UrlsController < ApplicationController
  # @deprecated materials に移行します
  def volunteer_help
    redirect_to "https://docs.google.com/document/d/1jHWnwourjUq8TkiNpIjT64YnnJPnb_RedEpnOcqjIqI/edit?usp=sharing"
  end
end

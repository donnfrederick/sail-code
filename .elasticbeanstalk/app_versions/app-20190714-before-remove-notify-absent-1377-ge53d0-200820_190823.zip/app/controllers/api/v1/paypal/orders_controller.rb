module Api
  module V1
    module Paypal
      class OrdersController < ApiController

        def create
          # TODO
        end
      end
    end
  end
end

module Organizations
  module Users
    class NotificationsController < BaseController
      def show
      end
    end
  end
end

module Organizations
  module Users
    class AccountsController < BaseController
      def index
      end
    end
  end
end

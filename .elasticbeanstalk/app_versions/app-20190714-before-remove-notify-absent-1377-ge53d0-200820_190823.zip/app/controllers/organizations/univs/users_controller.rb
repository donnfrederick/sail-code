module Organizations
  module Univs
    class UsersController < ::Organizations::Users::UsersController
      include Concerns::Language
      include Concerns::Industries
      include Concerns::Univs
      include ::Organizations::OrganizationSectionHelper

      add_flash_types :success, :info, :warning, :danger
      before_action :verify_student, only: [:show, :edit, :update, :destroy]
      before_action :the_dimension, :the_users_org_sections_in_section, :the_at_max_users, only: [:list]
      # before_action :to_new_invitation,                                                    only: [:new, :create]
      # before_action :the_hobbies, :the_purposes,                                           only: [:edit, :update]
      # before_action :the_dimensions,                                                       only: [:list, :list_no_specify, :edit, :update, :destroy]

      # validates :update do
      #   integer :user_id, required: true, description: "section ID"
      #   array :hobbies, required: true, description: "最大3つまで\n1:料理, 2:読書, 3:スポーツ, 4:歴史, 5:音楽, 6: 芸術, 7:哲学, 8:旅行, 9:社会"
      #   array :purposes, required: true, description: "最大3つまで\n1:若い人との会話を楽しみたい, 2:若い世代に貢献したい, 3:仕事や日常の経験を伝えたい, 4:日本語を教えたい"
      # end

      validates :delete do
        integer :user_id, required: true, description: "user ID"
      end

      # ユーザー一覧 (+ページネーション)
      def index
        @q = current_staff.organization.users.where(type: 'Student').ransack(params[:q])
        @students = @q.result(distinct: true).page(params[:page]).per(50)
        respond_to do |format|
          format.html
          format.json do
            render json: Student.find_by(encrypted_email: Student.encrypt_email(params[:email]))
          end
        end
      end

      def show
        @conversations = @student.conversations.order(start_at: :DESC).page(params[:page]).per(50)
      end

      def new
        @student = Student.new
      end

      def create
        @student = Student.find_or_initialize_by(encrypted_email: Student.encrypt_email(params[:student][:email]))
        if @student.organization_sections.exists?
          @error_message = ['this student already blongs to another section']
          render 'organizations/univs/users/new'
          return
        end

        entry_attributes

        if @student.save
          IssueCreateService.new(@student).create_organization_sections! if @student.issues.find_by(type: 'OrganizationSectionIssue').blank?
          redirect_to :organizations_univs_users, success: @message
        else
          @error_message = @student.errors.full_messages
          render 'organizations/univs/users/new'
        end
      end

      def edit
      end

      def update
        params[:student].delete(:password) if params[:student][:password].blank?
        @student.assign_attributes(student_params)

        if @student.save
          IssueCreateService.new(@student).create_organization_sections! if @student.issues.find_by(type: 'OrganizationSectionIssue').blank?
          redirect_to organizations_univs_user_path(@student), success: "#{@student.name_en} is a new student and successfully updated"
        else
          @error_message = @student.errors.full_messages
          render 'organizations/univs/users/edit'
        end

      end

      # def list(page = 1)
      #   page = params[:page] if params[:page].present?
      #   per_page = params[:per_page].present? ? params[:per_page] : max_user_in_table

      #   user_ids = @users_org_sections_in_section.map(&:user_id)
      #   @users_in_section = @users_org_sections_in_section.paginate(page: page, per_page: per_page)
      #   @pagination = @users_in_section
      # end

      # def list_no_specify
      #   redirect_to view_context.org_user_list_path(role_type, @dimensions[0].id)
      # end



      # def update
      #   @user.assign_hobbies  = filtered_nums(params[:hobbies])
      #   @user.assign_purposes = filtered_nums(params[:purposes])

      #   if @user.errors.empty? && @user.save
      #     redirect_to "/organizations/univs/users/list"
      #   else
      #     flash[:danger] = error_messages_of(@user)
      #     render "edit"
      #   end
      # end

      def destroy
        @student.organization_sections.destroy_all
        redirect_to :organizations_univs_users, success: "#{@student.name_en} has been successfully removed"
      end

      protected

      def find_role_user_by(conditions)
        Student.find_by(conditions)
      end

      def the_dimension(dimension_id = nil)
        @dimension = if dimension_id.present?
                       OrganizationSection.find_by(id: dimension_id)
                     else
                       OrganizationSection.find_by(id: params[:dimension_id])
                     end
        @current_section = @dimension

        redirect_to view_context.org_error_no_contract("section") if @current_section.blank?
      end

      def the_dimensions
        @dimensions = [current_staff.organization_section]
        @sections = @dimensions
      end

      # def the_hobbies
      #   @hobbies = Hobby.by_student.all
      # end

      # def the_purposes
      #   @purposes = Purpose.by_student.all
      # end

      def the_at_max_users
        @at_max_users = at_max_users_in?
      end

      def the_users_org_sections_in_section
        @users_org_sections_in_section ||= current_staff.organization_section.users
      end

      def at_max_users_in?
        @users_org_sections_in_section.count >= max_user_in_dimension
      end

      def to_new_invitation
        redirect_to view_context.org_invitation_new_path(@role_type)
      end

      private
      def student_params
        params[:student][:organization_section_ids] = [params[:student][:organization_section_ids]]
        attrs = Student.column_names.map { |m| m.to_sym }
        attrs.push(:email, :password, organization_section_ids: [])
        params.require(:student).permit(attrs)
      end

      def entry_attributes
        if @student.new_record?
          @student.assign_attributes(student_params)
          @message = "#{@student.name_en} is a new student and successfully registered to #{@student.organization_sections.first.name}"
        else
          @student.assign_attributes(organization_section_ids: [params[:student][:organization_section_ids]])
          @message = "#{@student.name_en} was already take part in sail and successfully registered to #{@student.organization_sections.first.name}"
        end
      end

      def verify_student
        @student = Student.find(params[:id])
        unless @student.organizations.first == current_staff.organization
          redirect_to :organizations_univs_users, warning: 'You are not authorized to access this student'
          return
        end
      end

      def available_seats
        current_staff.organization.name_kana.to_i + OrganizationSectionIssue.where(user: current_staff.organization.users.where(type: 'Student')).sum(:conversations)
      end


    end
  end
end

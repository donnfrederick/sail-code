class Organizations::AccountsController < ApplicationController
  def index
  end
end

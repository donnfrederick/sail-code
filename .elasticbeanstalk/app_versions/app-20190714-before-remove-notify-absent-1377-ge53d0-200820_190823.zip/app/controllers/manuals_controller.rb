# @deprecated materials に移行します
class ManualsController < ApplicationController
  def redirect_nh_video
    redirect_to "https://www.youtube.com/watch?v=GNPtdik9vbA&list=PLwwxsAlu3rr8iLxoKi9U6AheHrGe9b6Ri"
  end

  def redirect_univ_video
    redirect_to "https://www.youtube.com/watch?v=jOOlqo_1SNE&list=PLwwxsAlu3rr8gq5XBi53oVGlephtPwzgW"
  end

  def redirect_teacher_pdf
    redirect_to "https://www.helte.jp/downloads/sail-senior-teacher-ja.pdf"
  end
end

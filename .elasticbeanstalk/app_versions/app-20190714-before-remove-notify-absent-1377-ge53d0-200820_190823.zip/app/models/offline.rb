class Offline < UsersNetworkActivity

end

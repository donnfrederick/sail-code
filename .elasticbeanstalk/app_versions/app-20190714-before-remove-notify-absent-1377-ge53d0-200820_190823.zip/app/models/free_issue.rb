class FreeIssue < Issue
end

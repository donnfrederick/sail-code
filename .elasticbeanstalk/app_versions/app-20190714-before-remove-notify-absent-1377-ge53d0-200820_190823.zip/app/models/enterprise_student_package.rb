class EnterpriseStudentPackage < Package
end

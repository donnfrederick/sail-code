class GradeMember < Grade
end

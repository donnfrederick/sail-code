class User
  def evaluate
    {
      "1": self.evaluation_very_funny,
      "2": self.evaluation_lovely,
      "3": self.evaluation_amazing,
      "4": self.evaluation_fine,
    }
  end
end

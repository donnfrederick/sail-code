class User
  has_many :coupon_owners
end

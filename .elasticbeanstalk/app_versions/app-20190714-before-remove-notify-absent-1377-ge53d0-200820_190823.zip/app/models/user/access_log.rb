class User
  def self.cleanup_redis_access_log_all
    User.find_each do |user|
      begin
        activities = []
        user.access_log_read_each do |user_access, _error|
          activities << user_access if user_access.present?
        end
        UserAccess.import activities
        user.access_log_clear!
      rescue => e
        Rails.logger.error e.full_message
      end
    end
  end
end

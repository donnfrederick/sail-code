class IndividualTeacherPackage < Package
end

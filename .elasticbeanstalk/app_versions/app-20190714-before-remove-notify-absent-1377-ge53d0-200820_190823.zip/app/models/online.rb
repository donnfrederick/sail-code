class Online < UsersNetworkActivity

end

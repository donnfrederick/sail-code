class GradePlatinum < Grade
end

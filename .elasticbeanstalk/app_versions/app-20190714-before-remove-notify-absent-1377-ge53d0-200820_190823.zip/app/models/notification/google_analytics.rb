class Notification
  def google_analytics_event
    # TODO
    1
  end
end

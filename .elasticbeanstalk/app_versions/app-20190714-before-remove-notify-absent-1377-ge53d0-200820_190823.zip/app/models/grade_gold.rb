class GradeGold < Grade
end

class IndividualStudentPackage < Package
end

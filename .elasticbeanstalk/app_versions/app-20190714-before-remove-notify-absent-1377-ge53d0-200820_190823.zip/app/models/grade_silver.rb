class GradeSilver < Grade
end

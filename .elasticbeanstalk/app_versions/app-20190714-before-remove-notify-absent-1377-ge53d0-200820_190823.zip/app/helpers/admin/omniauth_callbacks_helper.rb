module Admin::OmniauthCallbacksHelper
end

ActiveAdmin.register_page "GroupConfigs" do
  menu label: I18n.t("activerecord.groups.configs"), priority: 99, url: "#"
end

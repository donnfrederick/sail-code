ActiveAdmin.register_page "Stats" do
  menu priority: 98, label: "統計データ"

  page_action :download, method: :get
  page_action :free_report, method: :post
  page_action :monthly_report, method: :get

  content do
    params[:q].present? ? q = params[:q] : q = 'overall'
    users = User.where(created_at: Time.now.ago(2.months)..Time.now)
    conversations = Conversation.where(created_at: Time.now.ago(2.months)..Time.now)
    issues = Issue.where.not(type: 'FreeIssue').where(created_at: Time.now.ago(2.months)..Time.now)

    render 'shared/stats', data: {q: q, users: users, conversations: conversations, issues: issues, cn: params[:cn]}
  end

  controller do
    def mau(type)
      Conversation.where(created_at: Time.now.last_month.beginning_of_day..Time.now.end_of_day).pluck(type).uniq.size
    end

  
    def percent(fraction,denominator)
      ((fraction.to_f * 100)/(denominator.to_f)).round(1)
    end

    def churn_rate(beginning,churn,gain)
      ((churn.size.to_f * 100)/(beginning.size.to_f + gain.size.to_f)).round(1)
    end

    def free_report
      csv_data = CSV.generate do |csv|
        csv << ['所属','ID','お名前','会話回数','予約キャンセル','会話時間','合計会話回数','合計会話時間']
        Organization.where(deleted_at: nil).includes(:users).each do |org|
          next if org.users.empty?
          org.users.each do |u|
            next if u.conversations.empty?
            all = u.conversations.select(:status, :start_at)
            cs = all.where(start_at: report_date[:start_at]..report_date[:end_at])
            cancels = 0
            if u.is_a?(Teacher)
              name = u.name_ja 
              cancels = CancelledConversation.where(conversation_id: cs.ids).where(reason: 'teacher').size if cs.any?
            else
              name = u.name_en
              cancels = CancelledConversation.where(conversation_id: cs.ids).where(reason: 'student').size if cs.any?
            end
            csv << [org.name_ja,u.id,name,"#{cs.where(status: 'completed').size}回","#{cancels}回","#{cs.where(status: 'completed').size * 25}分","#{all.where(status: 'completed').size}回","#{all.where(status: 'completed').size * 25}分"]
          end
        end
      end
      csv_data = csv_data.encode(Encoding::SJIS, invalid: :replace, undef: :replace)
      send_data csv_data, type:'text/csv', filename: "free_report_#{report_date[:start_at].strftime('%Y%m%d')}_#{report_date[:end_at].strftime('%Y%m%d')}.csv"
    end

    def monthly_report
      users = User.all.where(created_at: Time.now.ago(7.months)..Time.now).includes(:issues)
      conversations = Conversation.all.where(start_at: Time.now.ago(7.months)..Time.now)
      issues = Issue.where.not(type: 'FreeIssue').where(created_at: Time.now.ago(7.months)..Time.now)
      csv_data = CSV.generate do |csv|
        csv << %w(時間 新規	新シニア 新学生 課金 MAU(シニア)/% MAU(学生)/% 予約 成功 キャンセル アンマッチ 一人当たり予約数 獲得数 離脱数 ChurnRate)
        6.times do |i|
          st = users.where(type: "Student").where(created_at: Time.now.ago(i.months).all_month)
          us1 = users.where(created_at: Time.now.ago(i.months).all_month).pluck(:type)
          us2 = users.where(created_at: Time.now.ago((i + 1).months).all_month).pluck(:type)
          convs1 = conversations.where(start_at: Time.now.ago((i).months).all_month)
          convs2 = conversations.where(start_at: Time.now.ago((i + 1).months).all_month)
          is1 = issues.where(created_at: Time.now.ago((i).months).all_month).pluck(:type)
          is2 = issues.where(created_at: Time.now.ago((i + 1).months).all_month).pluck(:type)
          begninning = issues.where('created_at < ?', Time.now.ago(i.months).beginning_of_month)
          churn = issues.where(expired_at: Time.now.ago(i.months).all_month)
          gain = issues.where(created_at: Time.now.ago(i.months).all_month)

          csv << [
            "#{Time.now.ago(i.months).all_month.to_s.gsub('00:00:00 +0900','').gsub('23:59:59 +0900','').strip}",
            "#{us1.size}(#{percent(us1.size,us2.size)}%)",
            "#{us1.count('Teacher')}(#{percent(us1.count('Teacher'),us2.count('Teacher'))}%)",
            "#{us1.count('Student')}(#{percent(us1.count('Student'),us2.count('Student'))}%)",
            "#{is1.size}(#{percent(is1.size,is2.size)}%)",
            "#{convs1.pluck(:teacher_id).uniq.count}(#{percent(convs1.pluck(:teacher_id).uniq.count,convs2.pluck(:teacher_id).uniq.count)}%)",
            "#{convs1.pluck(:student_id).uniq.count}(#{percent(convs1.pluck(:student_id).uniq.count,convs2.pluck(:student_id).uniq.count)}%)",
            "#{convs1.size}",

            "#{convs1.where(status: 'completed').size}(#{percent(convs1.where(status: 'completed').size,convs1.size)}%)",
            "#{convs1.where(status: 'cancled').size}(#{percent(convs1.where(status: 'cancled').size,convs1.size)}%)",
            "#{convs1.where(student_id: nil).size}(#{percent(convs1.where(student_id: nil).size,convs1.size)}%)",
            "シニア #{(convs1.size.to_f / convs1.pluck(:teacher_id).uniq.size.to_f).round(1)} 学生 #{(convs1.where.not(student: nil).size.to_f / convs1.pluck(:student_id).uniq.size.to_f).round(1)}",
            "#{st.where(issues: {type: 'StripeIssue'}).size}(#{((st.where(issues: {type: 'StripeIssue'}).size.to_f) * 100 / st.size.to_f).round(1)}%)",
            "#{churn.size}",
            "#{churn_rate(begninning,churn,gain)}%"
          ]
        end
      end
      csv_data = csv_data.encode(Encoding::SJIS, invalid: :replace, undef: :replace)
      send_data csv_data, type:'text/csv', filename: "monthly_report_#{Time.now.strftime('%Y%m%d')}.csv"
    end

    def download
      respond_to do |format|
        format.html do
          selected_name = params[:name]
          class_name = selected_name.split("/").map {|s| s.camelize }.join("::")
          factory = Analytics::WeeklyStatsFactory.new
          statistics = eval("::#{class_name}.new(factory)")

          row = %w[No. Start End]
          row += statistics.columns.map do |column|
            "#{column}"
          end

          rows = [row]
          rows += Stat.where(name: selected_name).order(nth: :desc).map do |stat|
            list = [
              "#{stat.term[0]}#{stat.nth}",
              "#{I18n.l(stat.start_at.in_time_zone(current_admin_user.timezone), locale: current_admin_user.lang, format: :long_date)}",
              "#{I18n.l(stat.end_at.in_time_zone(current_admin_user.timezone), locale: current_admin_user.lang, format: :long_date)}",
            ]
            list += JSON.parse(stat.data).map {|v| "#{v}" }
            list.join(", ")
          end

          send_data rows.join("\n").encode("Shift_JIS"),
                    filename:    "#{params[:name]}.csv",
                    type:        'text/csv',
                    disposition: 'inline' # 画面に表示
        end
      end
    end

    private
    def report_params
      params.permit(:start_at, :end_at, :utf8, :authenticity_token, :commit)
    end

    def report_date
      date = report_params
      {
        start_at: (Time.new date["start_at(1i)"].to_i,date["start_at(2i)"].to_i,date["start_at(3i)"].to_i),
        end_at: (Time.new date["end_at(1i)"].to_i,date["end_at(2i)"].to_i,date["end_at(3i)"].to_i)
      }
    end
  end
end

ActiveAdmin.register_page "GroupPayment" do
  menu label: I18n.t("activerecord.groups.payment"), priority: 79, url: "#"
end
